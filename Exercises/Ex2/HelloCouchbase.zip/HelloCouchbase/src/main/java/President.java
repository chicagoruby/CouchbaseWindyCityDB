
class President
{
  String presidency;      
  String name;     
  String wikipedia_entry;   
  String took_office;    
  String left_office;   
  String party;
  String portrait;     
  String thumbnail;
  String notable;
  String home_state;
  String type;
}